@extends('layout')
@section('title', "Home Page")
@section('content')

@endsection
